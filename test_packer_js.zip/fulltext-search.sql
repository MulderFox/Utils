# CREATE FULLTEXT INDEX `tab_polozka_pobocka_nazev` ON `tab_polozka` (`polozka_nazev`);

# CREATE FULLTEXT INDEX `tab_akce_akce_nazev` ON `tab_akce` (`akce_nazev`);

# CREATE FULLTEXT INDEX `szn_sport_sport_nazev` ON `szn_sport` (`sport_nazev`);

SELECT tab_polozka.info

 FROM tab_akce
  JOIN tab_polozka ON tab_akce.id_akce = tab_polozka.id_akce
  JOIN szn_sport ON szn_sport.id_sport = tab_akce.id_sport

 WHERE tab_polozka.status = 4 AND szn_sport.id_sport > 0 AND
  MATCH(szn_sport.sport_nazev) AGAINST ("+sparta +p��bram" IN BOOLEAN MODE)
    
 UNION SELECT tab_polozka.info

 FROM tab_akce
  JOIN tab_polozka ON tab_akce.id_akce = tab_polozka.id_akce
  JOIN szn_sport ON szn_sport.id_sport = tab_akce.id_sport

 WHERE tab_polozka.status = 4 AND szn_sport.id_sport > 0 AND
  MATCH(tab_akce.akce_nazev) AGAINST ("+sparta +p��bram" IN BOOLEAN MODE)

 UNION SELECT tab_polozka.info

 FROM tab_akce
  JOIN tab_polozka ON tab_akce.id_akce = tab_polozka.id_akce
  JOIN szn_sport ON szn_sport.id_sport = tab_akce.id_sport

 WHERE tab_polozka.status = 4 AND szn_sport.id_sport > 0 AND
  MATCH(tab_polozka.polozka_nazev) AGAINST ("+sparta +p��bram" IN BOOLEAN MODE);