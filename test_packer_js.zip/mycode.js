a.b(a.c,{d:function(options){if(!this.length){options&&options.f&&window.g&&g.h("nothing selected, can't validate, returning nothing");return;}var i=a.j(this[0],'validator');if(i){return i;}i=new a.i(options,this[0]);a.j(this[0],'validator',i);if(i.k.onsubmit){this.l(".cancel:submit").click(function(){i.m=true;});this.submit(function(n){if(i.k.f)n.o();function p(){if(i.k.q){i.k.q.call(i,i.r);return false;}return true;}if(i.m){i.m=false;return p();}if(i.form()){if(i.s){i.t=true;return false;}return p();}else{i.u();return false;}});}return i;},v:function(){if(a(this[0]).w('form')){return this.d().form();}else{var v=false;var i=a(this[0].form).d();this.x(function(){v|=i.element(this);});return v;}},y:function(z){var aa={},$element=this;$.x(z.split(/\s/),function(){aa[this]=$element.ab(this);$element.ac(this);});return aa;},ad:function(ae,af){var element=this[0];if(ae){var ag=a.j(element.form,'validator').k.ad;var ah=a.i.ag(element);switch(ae){case "add":$.b(ah,a.i.ai(af));ag[element.name]=ah;break;case "remove":if(!af){delete ag[element.name];return ah;}var aj={};$.x(af.split(/\s/),function(index,method){aj[method]=ah[method];delete ah[method];});return aj;}}var j=a.i.ak(a.b({},a.i.al(element),a.i.am(element),a.i.an(element),a.i.ag(element)),element);if(j.ao){var ap=j.ao;delete j.ao;j=$.b({ao:ap},j);}return j;},aq:function(ar){return this.as(this.at(ar).au());}});a.b(a.av[":"],{aw:function(ax){return!a.ay(ax.value);},az:function(ax){return!!a.ay(ax.value);},ba:function(ax){return!ax.checked;}});a.bb=function(bc,bd){if(arguments.length==1)return function(){var be=a.bf(arguments);be.bg(bc);return a.bb.bh(this,be);};if(arguments.length>2&&bd.constructor!=Array){bd=a.bf(arguments).bi(1);}if(bd.constructor!=Array){bd=[bd];}a.x(bd,function(bj,bk){bc=bc.replace(new bl("\\{"+bj+"\\}","g"),bk);});return bc;};a.i=function(options,form){this.k=a.b({},a.i.bm,options);this.r=form;this.bn();};a.b(a.i,{bm:{bo:{},bp:{},ad:{},bq:"error",br:"label",u:true,bs:a([]),bt:a([]),onsubmit:true,bu:[],bv:function(element){this.bw=element;if(this.k.bx&&!this.by){this.k.bz&&this.k.bz.call(this,element,this.k.bq);this.ca(element).cb();}},cc:function(element){if(!this.cd(element)&&(element.name in this.ce||!this.cf(element))){this.element(element);}},cg:function(element){if(element.name in this.ce||element==this.ch){this.element(element);}},onclick:function(element){if(element.name in this.ce)this.element(element);},ci:function(element,bq){a(element).cj(bq);},bz:function(element,bq){a(element).ck(bq);}},cl:function(k){a.b(a.i.bm,k);},bo:{ao:"This field is required.",cm:"Please fix this field.",cn:"Please enter a valid email address.",url:"Please enter a valid URL.",date:"Please enter a valid date.",co:"Please enter a valid date (ISO).",cp:"Bitte geben Sie ein gültiges Datum ein.",number:"Please enter a valid number.",cq:"Bitte geben Sie eine Nummer ein.",cr:"Please enter only digits",cs:"Please enter a valid credit card.",ct:"Please enter the same value again.",cu:"Please enter a value with a valid extension.",cv:a.bb("Please enter no more than {0} characters."),cw:a.bb("Please enter no more than {0} characters."),cx:a.bb("Please enter at least {0} characters."),cy:a.bb("Please enter at least {0} characters."),cz:a.bb("Please enter a value between {0} and {1} characters long."),da:a.bb("Please enter a value between {0} and {1} characters long."),db:a.bb("Please enter a value between {0} and {1}."),dc:a.bb("Please enter a value between {0} and {1}."),dd:a.bb("Please enter a value less than or equal to {0}."),max:a.bb("Please enter a value less than or equal to {0}."),de:a.bb("Please enter a value greater than or equal to {0}."),min:a.bb("Please enter a value greater than or equal to {0}.")},df:false,prototype:{bn:function(){this.dg=a(this.k.bt);this.dh=this.dg.length&&this.dg||a(this.r);this.di=a(this.k.bs).at(this.k.bt);this.ce={};this.dj={};this.s=0;this.dk={};this.dl={};this.reset();var bp=(this.bp={});a.x(this.k.bp,function(dm,value){a.x(value.split(/\s/),function(index,name){bp[name]=dm;});});var ad=this.k.ad;a.x(ad,function(dm,value){ad[dm]=a.i.ai(value);});function dn(n){var i=a.j(this[0].form,"validator");i.k["on"+n.type]&&i.k["on"+n.type].call(i,this[0]);}a(this.r).dn("focusin focusout keyup",":text, :password, :file, select, textarea",dn).dn("click",":radio, :checkbox",dn);},form:function(){this.dp();a.b(this.ce,this.dq);this.dl=a.b({},this.dq);if(!this.v())a(this.r).dr("invalid-form.validate",[this]);this.ds();return this.v();},dp:function(){this.dt();for(var bj=0,elements=this.elements();elements[bj];bj++){this.du(elements[bj]);}return this.v();},element:function(element){element=this.dv(element);this.ch=element;this.dw(element);var aa=this.du(element);if(aa){delete this.dl[element.name];}else{this.dl[element.name]=true;}if(!this.dx()){this.dy.aq(this.di);}this.ds();return aa;},ds:function(dz){if(dz){a.b(this.dq,dz);this.ea=[];for(var name in dz){this.ea.aq({eb:dz[name],element:this.ec(name)[0]});}this.ed=a.ee(this.ed,function(element){return!(element.name in dz);});}this.k.ds?this.k.ds.call(this,this.dq,this.ea):this.ef();},eg:function(){if(a.c.eg)a(this.r).eg();this.dt();this.eh();this.elements().ck(this.k.bq);},dx:function(){return this.ei(this.dl);},ei:function(ej){var ek=0;for(var bj in ej)ek++;return ek;},eh:function(){this.el(this.dy).cb();},v:function(){return this.em()==0;},em:function(){return this.ea.length;},u:function(){if(this.k.u){try{a(this.en()||this.ea.length&&this.ea[0].element||[]).eo(":visible").focus();}catch(e){}}},en:function(){var bw=this.bw;return bw&&a.ee(this.ea,function(bk){return bk.element.name==bw.name;}).length==1&&bw;},elements:function(){var i=this,ep={};return a([]).at(this.r.elements).eo("input, select, textarea").eq(":submit, :reset, [disabled]").eq(this.k.bu).eo(function(){!this.name&&i.k.f&&window.g&&g.er("%o has no name assigned",this);if(this.name in ep||!i.ei($(this).ad()))return false;ep[this.name]=true;return true;});},dv:function(es){return a(es)[0];},dz:function(){return a(this.k.br+"."+this.k.bq,this.dh);},reset:function(){this.ed=[];this.ea=[];this.dq={};this.et=a([]);this.dy=a([]);this.t=false;},dt:function(){this.reset();this.dy=this.dz().aq(this.di);},dw:function(element){this.reset();this.dy=this.ca(element);},du:function(element){element=this.dv(element);if(this.cd(element)){element=this.ec(element.name)[0];}var ad=$(element).ad();var eu=false;for(method in ad){var ev={method:method,ew:ad[method]};try{var aa=a.i.ex[method].call(this,a.ay(element.value),element,ev.ew);if(aa=="dependency-mismatch"){eu=true;continue;}eu=false;if(aa=="pending"){this.dy=this.dy.eq(this.ca(element));return;}if(!aa){this.ey(element,ev);return false;}}catch(e){this.k.f&&window.g&&g.log("exception occured when checking element "+element.ez+", check the '"+ev.method+"' method");throw e;}}if(eu)return;if(this.ei(ad))this.ed.aq(element);return true;},fa:function(name,method){var fb=this.k.bo[name];return fb&&(fb.constructor==String?fb:fb[method]);},fc:function(){for(var bj=0;bj<arguments.length;bj++){if(arguments[bj]!==fd)return arguments[bj];}return fd;},fe:function(element,method){return this.fc(this.fa(element.name,method),element.title||fd,a.i.bo[method],"<strong>Warning: No message defined for "+element.name+"</strong>");},ey:function(element,ev){var eb=this.fe(element,ev.method);if(typeof eb=="function")eb=eb.call(this,ev.ew,element);this.ea.aq({eb:eb,element:element});this.dq[element.name]=eb;this.ce[element.name]=eb;},el:function(ff){if(this.k.fg)ff.aq(ff.fh(this.k.fg));return ff;},ef:function(){for(var bj=0;this.ea[bj];bj++){var er=this.ea[bj];this.k.ci&&this.k.ci.call(this,er.element,this.k.bq);this.fi(er.element,er.eb);}if(this.ea.length){this.et.aq(this.di);}if(this.k.fj){for(var bj=0;this.ed[bj];bj++){this.fi(this.ed[bj]);}}if(this.k.bz){for(var bj=0,elements=this.fk();elements[bj];bj++){this.k.bz.call(this,elements[bj],this.k.bq);}}this.dy=this.dy.eq(this.et);this.eh();this.el(this.et).fl();},fk:function(){return this.elements().eq(this.fm());},fm:function(){return a(this.ea).fn(function(){return this.element;});},fi:function(element,eb){var fo=this.ca(element);if(fo.length){fo.ck().cj(this.k.bq);fo.ab("generated")&&fo.fp(eb);}else{fo=a("<"+this.k.br+"/>").ab({"for":this.fq(element),fr:true}).cj(this.k.bq).fp(eb||"");if(this.k.fg){fo=fo.cb().fl().fs("<"+this.k.fg+">").parent();}if(!this.dg.ft(fo).length)this.k.fu?this.k.fu(fo,a(element)):fo.fv(element);}if(!eb&&this.k.fj){fo.text("");typeof this.k.fj=="string"?fo.cj(this.k.fj):this.k.fj(fo);}this.et.aq(fo);},ca:function(element){return this.dz().eo("[@for='"+this.fq(element)+"']");},fq:function(element){return this.bp[element.name]||(this.cd(element)?element.name:element.ez||element.name);},cd:function(element){return/radio|checkbox/bj.fw(element.type);},ec:function(name){var form=this.r;return a(document.fx(name)).fn(function(index,element){return element.form==form&&element.name==name&&element||null;});},fy:function(value,element){switch(element.fz.toLowerCase()){case 'select':return a("option:selected",element).length;case 'input':if(this.cd(element))return this.ec(element.name).eo(':checked').length;}return value.length;},ga:function(ap,element){return this.gb[typeof ap]?this.gb[typeof ap](ap,element):true;},gb:{"boolean":function(ap,element){return ap;},"string":function(ap,element){return!!a(ap,element.form).length;},"function":function(ap,element){return ap(element);}},cf:function(element){return!a.i.ex.ao.call(this,a.ay(element.value),element)&&"dependency-mismatch";},gc:function(element){if(!this.dk[element.name]){this.s++;this.dk[element.name]=true;}},gd:function(element,v){this.s--;if(this.s<0)this.s=0;delete this.dk[element.name];if(v&&this.s==0&&this.t&&this.form()){a(this.r).submit();}},ge:function(element){return a.j(element,"previousValue")||a.j(element,"previousValue",previous={gf:null,v:true,eb:this.fe(element,"remote")});}},gg:{ao:{ao:true},cn:{cn:true},url:{url:true},date:{date:true},co:{co:true},cp:{cp:true},number:{number:true},cq:{cq:true},cr:{cr:true},cs:{cs:true}},gh:function(className,ad){className.constructor==String?this.gg[className]=ad:a.b(this.gg,className);},am:function(element){var ad={};var gi=a(element).ab('class');gi&&a.x(gi.split(' '),function(){if(this in a.i.gg){a.b(ad,a.i.gg[this]);}});return ad;},an:function(element){var ad={};var$element=a(element);for(method in a.i.ex){var value=$element.ab(method);if(value!==fd&&value!==''){ad[method]=value;}}if(ad.cv&&/-1|2147483647|524288/.fw(ad.cv)){delete ad.cv;delete ad.cw;}return ad;},al:function(element){if(!a.gj)return{};var gk=a.j(element.form,'validator').k.gk;return gk?a(element).gj()[gk]:a(element).gj();},ag:function(element){var ad={};var i=a.j(element.form,'validator');if(i.k.ad){ad=a.i.ai(i.k.ad[element.name])||{};}return ad;},ak:function(ad,element){a.x({cy:'minlength',cw:'maxlength',da:'rangelength',de:'min',dd:'max',db:'range'},function(gl,gm){if(ad[gl]){ad[gm]=ad[gl];delete ad[gl];}});$.x(ad,function(gn,gp){if(gp===false){delete ad[gn];return;}if(gp.ap||gp.gq){var gr=true;switch(typeof gp.gq){case "string":gr=!!a(gp.gq,element.form).length;break;case "function":gr=gp.gq.call(element,element);break;}if(gr){ad[gn]=gp.ap!==fd?gp.ap:true;}else{delete ad[gn];}}});a.x(ad,function(ev,gs){ad[ev]=a.gt(gs)?gs(element):gs;});a.x(['minlength','maxlength','min','max'],function(){if(ad[this]){ad[this]=Number(ad[this]);}});a.x(['rangelength','range'],function(){if(ad[this]){ad[this]=[Number(ad[this][0]),Number(ad[this][1])];}});if(a.i.df){if(ad.min&&ad.max){ad.dc=[ad.min,ad.max];delete ad.min;delete ad.max;}if(ad.cx&&ad.cv){ad.cz=[ad.cx,ad.cv];delete ad.cx;delete ad.cv;}}return ad;},ai:function(j){if(typeof j=="string"){var gu={};a.x(j.split(/\s/),function(){gu[this]=true;});j=gu;}return j;},gv:function(name,method,eb){a.i.ex[name]=method;a.i.bo[name]=eb;if(method.length<3){a.i.gh(name,a.i.ai(name));}},ex:{ao:function(value,element,ap){if(!this.ga(ap,element))return "dependency-mismatch";switch(element.fz.toLowerCase()){case 'select':var options=a("option:selected",element);return options.length>0&&(element.type=="select-multiple"||(a.gw.gx&&!(options[0].z['value'].gy)?options[0].text:options[0].value).length>0);case 'input':if(this.cd(element))return this.fy(value,element)>0;default:return value.length>0;}},cm:function(value,element,ap){if(this.cf(element))return "dependency-mismatch";var previous=this.ge(element);if(!this.k.bo[element.name])this.k.bo[element.name]={};this.k.bo[element.name].cm=typeof previous.eb=="function"?previous.eb(value):previous.eb;if(previous.gf!==value){previous.gf=value;var i=this;this.gc(element);var j={};j[element.name]=value;a.gz({url:ap,ha:"abort",port:"validate"+element.name,hb:"json",j:j,fj:function(hc){if(!hc){var dz={};dz[element.name]=hc||i.fe(element,"remote");i.ds(dz);}else{var ce=i.t;i.dw(element);i.t=ce;i.ed.aq(element);i.ds();}previous.v=hc;i.gd(element,hc);}});return "pending";}else if(this.dk[element.name]){return "pending";}return previous.v;},cx:function(value,element,ap){return this.cf(element)||this.fy(value,element)>=ap;},cy:function(value,element,ap){return a.i.ex.cx.bh(this,arguments);},cv:function(value,element,ap){return this.cf(element)||this.fy(value,element)<=ap;},cw:function(value,element,ap){return a.i.ex.cv.bh(this,arguments);},cz:function(value,element,ap){var length=this.fy(value,element);return this.cf(element)||(length>=ap[0]&&length<=ap[1]);},da:function(value,element,ap){return a.i.ex.cz.bh(this,arguments);},min:function(value,element,ap){return this.cf(element)||value>=ap;},de:function(){return a.i.ex.min.bh(this,arguments);},max:function(value,element,ap){return this.cf(element)||value<=ap;},dd:function(){return a.i.ex.max.bh(this,arguments);},dc:function(value,element,ap){return this.cf(element)||(value>=ap[0]&&value<=ap[1]);},db:function(){return a.i.ex.dc.bh(this,arguments);},cn:function(value,element){return this.cf(element)||/^((([ax-hd]|\he|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^hf`{\|}~]|[\hg-\hh\hi-\hj\hk-\hl])+)*)|((\hm)((((\hn|\ho)*(\hp\hq))?(\hn|\ho)+)?(([\hr-\hs\ht\hu\hv-\hw\hx]|\hy|[\hz-\ia]|[\ib-\ic]|[\hg-\hh\hi-\hj\hk-\hl])|(\\([\hr-\ho\ht\hu\hp-\hx]|[\hg-\hh\hi-\hj\hk-\hl]))))*(((\hn|\ho)*(\hp\hq))?(\hn|\ho)+)?(\hm)))@((([ax-hd]|\he|[\hg-\hh\hi-\hj\hk-\hl])|(([ax-hd]|\he|[\hg-\hh\hi-\hj\hk-\hl])([ax-hd]|\he|-|\.|hf|~|[\hg-\hh\hi-\hj\hk-\hl])*([ax-hd]|\he|[\hg-\hh\hi-\hj\hk-\hl])))\.)+(([ax-hd]|[\hg-\hh\hi-\hj\hk-\hl])|(([ax-hd]|[\hg-\hh\hi-\hj\hk-\hl])([ax-hd]|\he|-|\.|hf|~|[\hg-\hh\hi-\hj\hk-\hl])*([ax-hd]|[\hg-\hh\hi-\hj\hk-\hl])))\.?$/bj.fw(element.value);},url:function(value,element){return this.cf(element)||/^(id?|ie):\/\/(((([ax-hd]|\he|-|\.|hf|~|[\hg-\hh\hi-\hj\hk-\hl])|(%[\ig-ih]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([ax-hd]|\he|-|\.|hf|~|[\hg-\hh\hi-\hj\hk-\hl])|(%[\ig-ih]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\ii-\ij]|\/|\?)*)?(\#((([ax-hd]|\he|-|\.|hf|~|[\hg-\hh\hi-\hj\hk-\hl])|(%[\ig-ih]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(element.value);
},
date: function(value, element) {
return this.optional(element) || !/Invalid|NaN/.test(new Date(value));
},
dateISO: function(value, element) {
return this.optional(element) || /^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$/.test(value);
},
dateDE: function(value, element) {
return this.optional(element) || /^\d\d?\.\d\d?\.\d\d\d?\d?$/.test(value);
},
number: function(value, element) {
return this.optional(element) || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/.test(value);
},
numberDE: function(value, element) {
return this.optional(element) || /^-?(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d+)?$/.test(value);
},
digits: function(value, element) {
return this.optional(element) || /^\d+$/.test(value);
},
creditcard: function(value, element) {
if ( this.optional(element) )
return "dependency-mismatch";
if (/[^0-9-]+/.test(value))
return false;
var nCheck = 0,
nDigit = 0,
bEven = false;
value = value.replace(/\D/g, "");
for (n = value.length - 1; n >= 0; n--) {
var cDigit = value.charAt(n);
var nDigit = parseInt(cDigit, 10);
if (bEven) {
if ((nDigit *= 2) > 9)
nDigit -= 9;
}
nCheck += nDigit;
bEven = !bEven;
}
return (nCheck % 10) == 0;
},
accept: function(value, element, param) {
param = typeof param == "string" ? param : "png|jpe?g|gif";
return this.optional(element) || value.match(new RegExp(".(" + param + ")$", "i")); 
},
equalTo: function(value, element, param) {
return value == jQuery(param).val();
}
}
});
;(function($) {
var ajax = $.ajax;
var pendingRequests = {};
$.ajax = function(settings) {
settings = jQuery.extend(settings, jQuery.extend({}, jQuery.ajaxSettings, settings));
var port = settings.port;
if (settings.mode == "abort") {
if ( pendingRequests[port] ) {
pendingRequests[port].abort();
}
return (pendingRequests[port] = ajax.apply(this, arguments));
}
return ajax.apply(this, arguments);
};
})(jQuery);
;(function($) {
$.each({
focus: 'ik',
blur: 'il'	
}, function( original, fix ){
$.event.special[fix] = {
setup:function() {
if ( $.browser.msie ) return false;
this.addEventListener( original, $.event.special[fix].handler, true );
},
teardown:function() {
if ( $.browser.msie ) return false;
this.removeEventListener( original,
$.event.special[fix].handler, true );
},
handler: function(e) {
arguments[0] = $.event.fix(e);
arguments[0].type = fix;
return $.event.handle.apply(this, arguments);
}
};
});
$.extend($.fn, {
delegate: function(type, delegate, handler) {
return this.bind(type, function(event) {
var target = $(event.target);
if (target.is(delegate)) {
return handler.apply(target, arguments);
}
});
},
triggerEvent: function(type, target) {
return this.triggerHandler(type, [jQuery.event.fix({ type: type, target: target })]);
}
})
})(jQuery);
