var tr_firstRow = 0;
var tr_secondRow = 0;
var tr_spacer = 0;
var selector = 0;
var element_details = new Array();
var element_counter =0;

var bgColor_pending = "#FFE759";
var bgColor_validated = "#FFE759";
var ftColor_pending = "#909090";
var ftColor_validated = "#000000";

var ajax_currentRequestItem = 0;
var ajax_requestCompleted = true;
var ajax_host = "";
var ajax_targetURL = "/rightTicket/ekupon.php";
var ajax_pendingQueue = new Array();

var ticket_vklad_tot = 0.0;
var ticket_kurs = 1.0;
var ticket_vklad = new Array();
var ticket_vyhra = 0.0;

var combinations = new Array();
var ticket_type = "AKO";

var marked_item = -1;

/**
* Vrati element na stranke s atributom id nastavenym na obj
*/
function getobject(obj)//{{{
{
	if (document.getElementById)
		return document.getElementById(obj)
	if (document.all)
		return document.all(obj)
}//}}}

/**
* Vrati polozku z pola element_details podla 'id', 
* jednoznacny identifikator v poli element_details.
*/
function getDetail(id)//{{{
{
	for (key in element_details)
	{
		if (element_details[key]['id']==id)
			return element_details[key];
	}
	return false;
}//}}}

/**
* Vrati poziciu polozky v poli element_details podla 'id'.
*/
function getDetailPosition(id)//{{{
{
	for (key in element_details)
	{
		if (element_details[key]['id']==id)
			return key;
	}
	return 0;
}//}}}

/**
* Vrati polozku z pola element_details podla 'bid_id'. (info cislo v tabulke nabidka)
*/
function getDetailByBidId(id, hodn)//{{{
{
	for (key in element_details)
	{
		if (element_details[key]['bid_id']==id && element_details[key]['hodn']==hodn)
			return element_details[key];
	}
	return false;
}//}}}

/**
* Vrati polozku z pola element_details podla 'info', (identifikator kurzu potrebny pre ekupon)
*/
function getDetailByMatchId(id)//{{{
{
	for (key in element_details)
	{
		if (element_details[key]['info']==id)
			return element_details[key];
	}
	return false;
}//}}}

/**
* Vrati poslednu nastavenu skupinu.
*/
function getLastCombination()//{{{
{
	var last = "A";
	for (var key in combinations)
	{
		if ((key=="T") || (combinations[key]==0))
			return last;
		last = key;
	}
}//}}}

/**
* Vrati pocet nastavenych skupin.
*/
function getCombinationsCount()//{{{
{
	var i=0;
	for (var key in combinations)
	{
		if (key == "T")
			return i;
		if (combinations[key]==0)
			return i;
		i++;
	}
}//}}}

/**
* Vrati pocet vsadenych cislenych hier.
* Ak je pocet 15 pridame polozky BONUS.
*/
function getPocetCisHer()//{{{
{
	var i=0;
	for (key in element_details)
	{
		if (element_details[key]['valid'] && element_details[key]['info']<0)
			i++;
	}
	return i;
}//}}}

/**
* Konvertovanie cisla na menu.
* Eg.: 1000 => 1 000
*/
function convertToCurrency(num)//{{{
{
	num = num.toString().replace(".",",");

	var result = "";
	var cur_reg = new RegExp("([^,]*)(.*)");
	var match = cur_reg.exec(num);
	if (match[2])
		result = match[2];
	else
		result = ",00";

	var counter = 0;
	for (var i=match[1].length-1;i>=0;i--)
	{
		result = match[1].charAt(i)+result;
		if (counter++==2)
		{
			result = " "+result;
			counter = 0;
		}
	}
	return result;
}//}}}

/**
* Odstrani div na zobrazovanie chyb.
*/
function ticket_hideError()//{{{
{
	var tmp = getobject('ticket_error');
	if (tmp)
		tmp.style.display = "none";
	ticket_unmarkConflict(marked_item);
}//}}}

/**
* Zobrazi chybu, ktora nastala pri spracovavani.
*/
function ticket_printError(msg)//{{{
{
	var tmp = getobject('ticket_error');
	if (tmp)
	{
		tmp.style.display = "block";
		if (tmp.childNodes.length>1)
			tmp.childNodes.item(1).data = " "+msg;
		else
			tmp.appendChild(document.createTextNode(" "+msg));
	}
}//}}}

/**
* Oznaci polozku tiketu na ktorej vznikol konflikt pri pridavani novej sazky.
*/  
function ticket_unmarkConflict(id)///{{{
{
	var tmp = getobject(id);
	var tmp2 = getobject(id+"_2");
	if (!tmp || !tmp2)
		return;

	for (var i=0; i<tmp.childNodes.length;i++)
		tmp.childNodes.item(i).style.backgroundColor = bgColor_validated;
	for (var i=0; i<tmp2.childNodes.length;i++)
		tmp2.childNodes.item(i).style.backgroundColor = bgColor_validated;
}//}}}

/**
* Odznaci konfliktnu polozku.
*/  
function ticket_markConflict(id)//{{{
{
	ticket_unmarkConflict(marked_item);

	var tmp = getobject(id);
	var tmp2 = getobject(id+"_2");
	if (!tmp || !tmp2)
		return;

	for (var i=0; i<tmp.childNodes.length;i++)
		tmp.childNodes.item(i).style.backgroundColor = "#ec732c";
	for (var i=0; i<tmp2.childNodes.length;i++)
		tmp2.childNodes.item(i).style.backgroundColor = "#ec732c";

	marked_item = id;
}//}}}

/**
* Zmena typu tiketu moznosti "AKO", "KOMBI" a "FALC".
*/
function ticket_changeType(sender, recalculate)//{{{
{
	// ak neexistuje sender (typicky chyba onLoad fcie) koniec
	if (!sender)
		return true;
	
	if (combinations['B'] == 0)
	{
		// ak nie je nastavena skupina B znemoznime nastavenie typu KOMBI a FALC
		disableOption("KOMBI");
		disableOption("FALC");
	}
	else
	{
		// je nastavena skupina B umoznime typ KOMBI
		enableOption("KOMBI");
		// ak je nastavena tutovka umoznime/znemoznime natavenie typu FALC
		if (combinations['T']>0)
			disableOption("FALC");
		else
			enableOption("FALC");
	}
	// zmena typu na AKO
	if (sender.id == "AKO")
	{
		// zobrazime pole pre kurz
		try
		{
			getobject('tiket_kurs').parentNode.style.display = "table-row";	
		}
		catch(e)
		{
			// IE nepozna table-row pre property display a vyhodi excpt
			getobject('tiket_kurs').parentNode.style.display = "block";	
		}
		ticket_changeVklady(1);
	}

	// zmena typu na KOMBI
	if (sender.id == "KOMBI")
	{
		// ak nie je nastavena aspon skupina "B", koniec
		if (combinations["B"]==0)
			return false;

		// skryjeme pole pre kurz
		getobject('tiket_kurs').parentNode.style.display = "none";		
		ticket_changeVklady(getCombinationsCount());
	}

	// zmena typu na FALC
	if (sender.id == "FALC")
	{
		// ak je nastavena skupina "T", alebo nie je nastavena "B" koniec
		if (combinations['T']>0 || combinations['B']==0)
			return false;
	
		// skryjeme pole pre kurz
		getobject('tiket_kurs').parentNode.style.display = "none";
		ticket_changeVklady(1);
	}

	// zmena typu na serveri
	ajax_execCommand(ajax_targetURL+"?chng_type="+sender.id, null);
	
	// oznacime v menu novy typ
	if (getobject(ticket_type))
		getobject(ticket_type).style.backgroundColor = "white";
	sender.style.backgroundColor = "#FFD006";

	ticket_type = sender.id;

	// ak mame prepocitat obsah tiketu
	if (recalculate)
		ticket_recalculate();
}//}}}

/**
* Zmena celkovych udajov tiketu (vklad, kurz, vyhra)
*/
function ticket_changeSummary()//{{{
{
	var tmp_vklad = getobject('tiket_vklad_0');
	var tmp_vyhra = getobject('tiket_vyhra');
	var tmp_kurs = getobject('tiket_kurs');
	
	// zmena vkladov pre tiket
	if (tmp_vklad)
	{
		var vklad_set = false;
		for (var i=0; i<ticket_vklad.length; i++)
		{
			tmp_vklad = getobject('tiket_vklad_'+i);
			if (tmp_vklad)
			{
				tmp_vklad.value = ticket_vklad[i];
				if (ticket_vklad[i] > 0.0)
					vklad_set = true;
			}
		}

		// ak je nastaveny aspon jeden vklad zobrazime moznost ulozenia tiketu
		if (vklad_set)
			getobject('tiket_save_button').style.visibility = "visible";
		else
			getobject('tiket_save_button').style.visibility = "hidden";
	}
	
	var mp = getobject("tiket_mp");
	if (mp)
		mp.innerHTML = ticket_vklad_tot/10.0;

	var tot = getobject("tiket_total");
	if (tot)
		tot.innerHTML = ticket_vklad_tot + (ticket_vklad_tot/10.0);

	// zmena vyhry pre tiket
	if (tmp_vyhra)
		tmp_vyhra.innerHTML = convertToCurrency(ticket_vyhra);

	// zmena kurzu pre tiket
	if (ticket_type == "AKO" && tmp_kurs)
	{
		if (element_details.length==0 || !ticket_kurs || ticket_kurs === 1)
			tmp_kurs.innerHTML = 0;
		else
			tmp_kurs.innerHTML = ticket_kurs;
	}

}//}}}


/**
* Zmena skupiny v selector polozky id na value
*/
function changeSelector(id, value)//{{{
{
	var tmp=getobject(id+"_2");
	if (!tmp)
		return;

	//najdeme spravnu polozku a nastavime ju
	var select = tmp.childNodes.item(0).childNodes.item(0);
	for (var i=0; i<select.options.length;i++)
	{
		if (select.options[i].text == value)
		{
			combinations[value]++;
			select.selectedIndex = i;
		}
	}
}//}}}

/**
* Zmena kombinacie na serveri pomocou AJAXu.
*/
function ticket_changeCombination()//{{{
{
	ticket_hideError();	

	var id = this.parentNode.parentNode.previousSibling.id;
	var value = this.options[parseInt(this.value)].text;
	var detail = getDetail(id);
	ajax_execCommand(ajax_targetURL+"?chng_skup="+value+"&kurs="+detail['bid_id']+"&hod="+detail['hodn'], ticket_changeCombinationDone);
}//}}}

function moveItem(det, pos)
{
	var id = det['id'];
	var det_pos = parseInt(getDetailPosition(id));
	if (det_pos == pos)
		return;

	//handle ticket item shift
	if (!getobject(id))
		return;
	
	var tr_1 = getobject(id);
	var tr_2 = getobject(id+"_2");

	var new_1 = tr_1.cloneNode(true);
	var new_2 = tr_2.cloneNode(true);
	var table = tr_1.parentNode;
	
	var el_pos = 2*pos;
	if (el_pos<0) 
		el_pos = 0;
	var bef = table.childNodes.item(el_pos);
	table.removeChild(tr_1);
	table.removeChild(tr_2);
	table.insertBefore(tr_1, bef);
	table.insertBefore(tr_2, bef);

	// handle detail array shift
	element_details.splice(det_pos, 1);
	element_details.splice(pos, 0, det);
}

/**
* Dokoncenie AJAX requestu na zmenu kombinacie.
*/  
function ticket_changeCombinationDone(req)//{{{
{
	var res = eval(req.responseText);
	// vynulujeme ref counting pre skupiny
	for (var key in combinations)
		combinations[key] = 0;
	
	// nacitame zoznam skupin pre jednotlive polozky
	for (var l=0; l<res.length; l++)
	{
		var detail = getDetailByBidId(res[l][1],res[l][0]);
		changeSelector(detail['id'], res[l][2]);
		moveItem(detail, l);
	}

	// zmena typu tiketu z FALC, KOMBI na AKO
	if (combinations['B']==0)
	{
		ticket_changeType(getobject("AKO"), true);
		disableOption("KOMBI");
		disableOption("FALC");
	}
	else
	{
		enableOption("KOMBI");
		
		if (combinations['T']>0)
		{
			disableOption("FALC");
			if (ticket_type=="FALC")
				ticket_changeType(getobject("KOMBI"), true);
		}
		else
		{
			enableOption("FALC");
		}
	}

	if (ticket_type == "KOMBI")
	{
		// ak je listok KOMBI a zmenil sa pocet kombinacii zmenime pocet inputov
		ticket_changeVklady(getCombinationsCount());
	}
}//}}}

/**
* Vytvori novy zaznam v tikete.
*/
function createTicketItemRow(parentNode, detail, id)//{{{
{
	// ak este nie je vytvoreny prototyp, koniec
	if (!parentNode || !tr_firstRow)
		return false;

	// prvy riadok
	var first = tr_firstRow.cloneNode(true);
	first.id = id;
	first.childNodes.item(0).appendChild(document.createTextNode(detail['match_name']));

	if (detail['hodn'] == 0) //ak je hodnota kurzu 0 pridame len typ sazky
		first.childNodes.item(1).appendChild(document.createTextNode(detail['bid_typ']));		
	else // hodnota je nenulova pridame ju k typu sazky
		first.childNodes.item(1).appendChild(document.createTextNode(detail['hodn']+detail['bid_typ']));	

	var img = first.childNodes.item(2);
	if (detail['info']==9998)
	{
		// ak je polozka bonus, schovame ikonu na zmazanie polozky
		img.removeChild(img.childNodes.item(0));
	}
	else
	{
		// zaregistrujeme callback na zmazavanie
		img.childNodes.item(0).alt = "?del_id_kurs="+detail['bid_id']+"&del_kurs_hodnota="+detail['hodn'];
		img.childNodes.item(0).onclick = ticket_removeItem;
	}
/**/
	// druhy riadok
	var second = tr_secondRow.cloneNode(true);
	second.id = id+"_2";

	var select = second.childNodes.item(0).childNodes.item(0);
	select.onchange = ticket_changeCombination;

	if (detail['info']==9998) // ak je polozka bonus pri ciselnych sazkach
	{
		select.disabled="disabled";
		select.style.color = "black";
	}

	if (detail['info'] != 0)
		second.childNodes.item(0).appendChild(document.createTextNode(" "+detail['info']+" - "+detail['match_time']));
	second.childNodes.item(1).appendChild(document.createTextNode(detail['kurs']));
	
	parentNode.appendChild(first);
	parentNode.appendChild(second);
//	parentNode.appendChild(tr_spacer.cloneNode(true));

	// zmenime skupinu v selektore
	changeSelector(id, detail['skup']);
	return true;
}//}}}

/**
* Natavi riadok v tikete na potvrdeny.
* (Zmena farieb ...)
*/
function ticket_itemValid(id, callSummary)//{{{
{
	var elem = getobject(id);
	if (!elem)
		return;
	
	// zmeni farby vo vsetkych bunkach v prvom, druhom riadku 
	for (var i=0; i<elem.childNodes.length; i++)
	{
		elem.childNodes.item(i).style.color = ftColor_validated;
		elem.childNodes.item(i).style.backgroundColor = bgColor_pending;
	}
	elem = getobject(id+"_2");
	for (var i=0; i<elem.childNodes.length; i++)
	{
		elem.childNodes.item(i).style.color = ftColor_validated;
		elem.childNodes.item(i).style.backgroundColor = bgColor_pending;
	}

	// oznacime bunku v tabulke nabidka_kurzy
	var detail = getDetail(id);
/*	var tmp = getobject(detail['bid_id']);
	if (tmp)
		tmp.parentNode.style.backgroundColor = "#FFE759";
*/
	detail['valid'] = true;
}//}}}

/**
* Vymaze riadok z tiketu. 
*/
function ticket_itemInvalid(id)//{{{
{
	var elem = getobject(id);
	var elem2 = getobject(id+"_2");
	if (!elem)
		return;
	
	// odsranieme polozky z tiketu	
	var parent = elem.parentNode;
	parent.removeChild(elem);	
	parent.removeChild(elem2);	

	var detail = getDetail(id);

	// element bol potvrdeny
	var tmp = getobject(detail['bid_id']);
	if (tmp && tmp.parentNode)
	{
		// odsranime oznacenie v nabidka_kurzy
		//tmp.parentNode.style.backgroundColor = tmp.parentNode.previousSibling.style.backgroundColor;
		// znizime ref counter pre skupiny
		combinations[detail['skup']]--;
	}
	
	// odstranime polozky z element_details
	element_details.splice(getDetailPosition(id), 1);
}//}}}

/**
* Zmena vkladov pre tiket. Pridavanie dalsich poloziek pri KOMBI, odoberanie pri AKO a FALC.
*/
function ticket_changeVklady(count)//{{{
{
	// vytvorime dalsie polozky pre vklad
	var parent = getobject('tiket_vklad_0').parentNode.parentNode;
	var table = parent.parentNode;
	var nextElement = getobject('tiket_mp').parentNode;
	for (var i=0;i<count;i++)
	{
		var tmp = getobject('tiket_vklad_'+i);
		if (tmp)
		{
			tmp.value = ticket_vklad[i];
			tmp.parentNode.previousSibling.innerHTML = count==1?"Vklad":"Vklad "+(i+1)+"/"+count;
		}
		else
		{
			if (!ticket_vklad[i])
				ticket_vklad[i] = 0;
			var newRow = parent.cloneNode(true);
			newRow.childNodes.item(0).innerHTML = "Vklad "+(i+1)+"/"+count;
			newRow.childNodes.item(1).firstChild.id = "tiket_vklad_"+i;
			newRow.childNodes.item(1).firstChild.value = ticket_vklad[i];
			table.insertBefore(newRow, nextElement);
/*			var newInput = document.createElement('input');
			newInput.setAttribute('class','textfield');
			newInput.setAttribute('className','textfield');
			newInput.style.textAlign = "right";
			newInput.id = "tiket_vklad["+i+"]";
			newInput.value = "0";
			parent.appendChild(newInput);*/
		}
/*		if (ticket_vklad.length<i+1)
			ticket_vklad[i] = 0;*/
	}
	var tmp_vklad;
	for (var k=i;k<ticket_vklad.length;k++)
	{
		tmp_vklad = getobject('tiket_vklad_'+k).parentNode.parentNode;
		if (tmp_vklad)
			table.removeChild(tmp_vklad);
	}
	ticket_vklad.splice(count, ticket_vklad.length-count);
}//}}}

/**
* Zakaze prepinac typu tiketu.
*/
function disableOption(name)//{{{
{
	var tmp = getobject(name);
	if (tmp)
	{
		tmp.setAttribute('class','disabled');
		tmp.setAttribute('className','disabled');
	}
}//}}}

/**
* Povoli prepinac typu tiketu.
*/
function enableOption(name)//{{{
{
	var tmp = getobject(name);
	if (tmp)
	{
		tmp.setAttribute('class','unselected');
		tmp.setAttribute('className','unselected');
	}
}//}}}

/**
* Vycisti tiket.
*/
function ticket_clear(remove_from_server)//{{{
{
	ticket_hideError();

	var parentNode = getobject('ticket_content');
	// vymazeme obsah tiketu
	while (parentNode.firstChild)
	{
		parentNode.removeChild(parentNode.firstChild);
	}

	// odstranime podfarbenie v nabidka_kurzy
/*	for (key in element_details)
	{
		var tmp = getobject(element_details[key]['bid_id']);
		if (tmp && tmp.parentNode)
			tmp.parentNode.style.backgroundColor = tmp.parentNode.previousSibling.style.backgroundColor;
	}
*/
	// vymazeme pole element_details
	element_details.splice(0, element_details.length);

	// mame odstranit tiket aj zo serveru?
	if (remove_from_server)
	{
		ticket_kurs = 1.0;
		ticket_vyhra = 0.0;
		for (var key in combinations)
			combinations[key] =0;
		ticket_changeType(getobject("AKO"), true);
		ticket_changeSummary();
		ajax_execCommand(ajax_targetURL+"?clear_ticket=", null);
	}
}//}}}

/**
* Update polozky tiketu. Pouziva sa hlavne pri ciselnych hrach kde sa neda zo stranky nacita
* kurz, info cislo a cislo tahu tj. nemozeme ich nacitat priamo pri vkladani.
*/
function ticket_updatePolozky(id, name, kurz, info)//{{{
{
	var tmp = getobject(id);
	var tmp2 = getobject(id+"_2");
	if (!tmp || !tmp2)
		return
	tmp.childNodes.item(0).innerHTML = name;
	tmp2.childNodes.item(0).appendChild(document.createTextNode(info));
	tmp2.childNodes.item(1).innerHTML = kurz;

	var detail = getDetail(id);
	detail['kurs'] = kurz;
	detail['info'] = parseInt(info);
	detail['match_name'] = name;
}//}}}

/**
* Prida novy zaznam do tiketu, ktory je este v nepotvrdenom stave.
* Az po overeni pomocou AJAXu sa vola ticket_itemValid, ticket_itemInvalid.
*/
function ticket_addPendingItem(sender)//{{{
{
	ticket_hideError();	

	var tbl_ticketContent = getobject('ticket_content');
	
	// riadok z tabulky nabidka_kurzy na ktory uzivatel klikol
	var row = sender.parentNode.parentNode;
	// parent je <TR> pridavame zapas
	if (row.tagName == "TR")
	{
		// prvy riadok v tabulke do ktorej uzivatel klikol, kvoli zahlaviu resp. typu sazky ktoru uzivatel chce ("vyhra", "02", "10" ....)
		var firstRow = row.parentNode.previousSibling.childNodes.item(1);

		// vyparsovanie id kurzu pre zapas
		var bid_id = sender.getAttribute('href');
		bid_id = bid_id.substr(bid_id.indexOf('=')+1, bid_id.length - bid_id.indexOf('='));

		// vyparsovanie info cisla zapasu
		var match_info = row.childNodes.item(0).firstChild.nodeValue;

		// vyparsovanie casu zapasu
		var match_time = row.childNodes.item(row.childNodes.length-1).firstChild.nodeValue;

		// vyparsovanie meno zapasu
		var match_name = "";
		if (row.childNodes.item(1).childNodes.item(0).nodeValue)
			match_name = row.childNodes.item(1).childNodes.item(0).nodeValue;
		else
			match_name = row.childNodes.item(1).childNodes.item(1).nodeValue;

		//*** Ak uz tento zapas bol vsadeny **/
		var existing_item = getDetailByMatchId(match_info);
		if (existing_item)		
		{
			ticket_markConflict(existing_item['id']);
			ticket_printError("Příležitost už v tikete existuje.");
			return true;
		}
	
		// kurz na ktory uzivatel klikol
		var selected_bid = sender.firstChild.nodeValue;
		selected_bid = selected_bid.replace(",",".");
	
		// typ kurzu na ktory uzivatel klikol {musime prejst zahlavie} (vyhra, remiza ... )
		var bid_type_idx = 0;;
		for (var i=0; i<row.childNodes.length; i++)
		{
			if (row.childNodes.item(i).firstChild == sender)
			{
				bid_type_idx = i;
				break;
			}
		}
		var selected_bid_type = firstRow.childNodes.item(bid_type_idx).innerHTML;
	
		// vytvorime si novu polozku v element_details
		element_details[element_counter] = new Array();
		element_details[element_counter]['valid'] = false;
		element_details[element_counter]['id'] = element_counter;
		element_details[element_counter]['info'] = match_info;
		element_details[element_counter]['skup'] = getLastCombination();
		element_details[element_counter]['bid_id'] = bid_id;
		element_details[element_counter]['kurs'] = parseFloat(selected_bid);
		element_details[element_counter]['hodn'] = 0;
		element_details[element_counter]['match_name'] = match_name;
		element_details[element_counter]['match_time'] = match_time;
		element_details[element_counter]['bid_typ'] = selected_bid_type;
	
	}
	else //pridavame ciselnu hru
	{
		var cur_reg = new RegExp("[^?]*?[^=]*=([^&]*)&[^=]*=(.*)");
		var match = cur_reg.exec(sender.href);
		var bid_id = match[1];
		var hodn = match[2];
		match = cur_reg.exec(document.location.href);
		var loteria = match[1];
		var loter_type = "K";
		switch (loteria)
		{
			case "akumulator":
				loter_type = "A";
				break;
			case "variator":
				loter_type = "V";
				break;
		}
		var date_regexp = new RegExp("([^-]*)-([^-]*)-([^-]*)");
		match = date_regexp.exec(match[2]);
		var datum = match[3]+"."+match[2]+"./18:15";
		var datum_whole = match[3]+"."+match[2]+"."+match[1];

		// vytvorime si novu polozku v element_details
		element_details[element_counter] = new Array();
		element_details[element_counter]['valid'] = false;
		element_details[element_counter]['id'] = element_counter;
		element_details[element_counter]['info'] = 0;
		element_details[element_counter]['skup'] = getLastCombination();
		element_details[element_counter]['bid_id'] = bid_id;
		element_details[element_counter]['kurs'] = "";
		element_details[element_counter]['hodn'] = hodn;
		element_details[element_counter]['match_name'] = "Tah 1:"+datum_whole;
		element_details[element_counter]['match_time'] = datum;
		element_details[element_counter]['bid_typ'] = loter_type;
	
	}

	// vytvorime novy riadok v tikete
	if (!createTicketItemRow(tbl_ticketContent, element_details[element_counter], element_counter))
		return true;

	// pridame element do fronty cakatelov na potvrdenie
	var arrayIndex = ajax_pendingQueue.length;
	ajax_pendingQueue[arrayIndex] = new Array();
	ajax_pendingQueue[arrayIndex]["matchId"] = bid_id;
	ajax_pendingQueue[arrayIndex]["hodn"] = element_details[element_counter]['hodn'];
	ajax_pendingQueue[arrayIndex]["id"] = element_counter;
	if (ajax_pendingQueue.length == 1)
		ticket_validateItems();

	element_counter++;	
	return true;
}//}}}

/**
* AJAXove overovanie poloziek z tiketu.
*/
function ticket_validateItems()//{{{
{
	// ak predchadzajuci dotaz neskoncil, alebo uz nie je co potvrdzovat koniec
	if (!ajax_requestCompleted || ajax_pendingQueue.length==0)
		return;

	// vyberieme prvy dotaz	
	var item =  ajax_pendingQueue[0]["matchId"];
	var hodnota =  ajax_pendingQueue[0]["hodn"];
	ajax_execCommand(ajax_targetURL+"?add_id_kurs="+item+"&add_kurs_hodnoty="+hodnota, ticket_validateItemsDone);
}//}}}

/**
* Callback funkcia pre overovanie poloziek z tiketu.
*/
function ticket_validateItemsDone(req)//{{{
{
	var currentItem = ajax_pendingQueue.shift();
	currentItem = currentItem["id"];
	// ak nebol potvrdeny vrati sa prazdny responseText
	if (req.responseText=="")
	{
		ticket_printError("Nepovolená kombinace.");
		// odstranime zaznam z tiketu
		ticket_itemInvalid(currentItem);
	}
	else
	{
		// potvrdime item
		ticket_itemValid(currentItem);
		// nacitame kurz a vyhru
		var res=eval(req.responseText);
		ticket_kurs = res[0];
		ticket_vyhra = res[1];
		var name = res[2];
		var kurz = res[3];
		var info = res[4];
		if (parseInt(info)<0)
			ticket_updatePolozky(currentItem, name, kurz, info);
		ticket_changeSummary();
		if (getPocetCisHer() == 15)
		{
			element_details[element_counter] = new Array();
			element_details[element_counter]['valid'] = false;
			element_details[element_counter]['id'] = element_counter;
			element_details[element_counter]['info'] = 9998;
			element_details[element_counter]['skup'] = getLastCombination();
			element_details[element_counter]['bid_id'] = 0;
			element_details[element_counter]['kurs'] = 1.1;
			element_details[element_counter]['hodn'] = 0;
			element_details[element_counter]['match_name'] = "Bonus";
			element_details[element_counter]['match_time'] = "31.12./00:00";
			element_details[element_counter]['bid_typ'] = "A 15";
	
			var tbl_ticketContent = getobject('ticket_content');
			createTicketItemRow(tbl_ticketContent, element_details[element_counter], element_counter);
			ticket_itemValid(element_counter);
			element_counter++;
		}
	}
	
	ajax_currentRequestItem = 0;
	ticket_validateItems();

}//}}}


/**
* AJAXove odstranenie zaznamu z tiketu.
*/
function ticket_removeItem()//{{{
{
	ticket_hideError();
	var detail  = getDetail(this.parentNode.parentNode.id);
	if (!detail['valid'])	
		return;

	var bonus = getDetailByMatchId('9998');
	if (bonus && detail['info']<0)
	{
		var tbl = getobject('ticket_content');
		var tmp = getobject(bonus['id']);
		tbl.removeChild(tmp.nextSibling);
		tbl.removeChild(tmp.nextSibling);
		tbl.removeChild(tmp);

		var bonusPos = getDetailPosition(bonus['id']);
		element_details.splice(bonusPos, 1);
	}
	ticket_itemInvalid(this.parentNode.parentNode.id);
	ajax_execCommand(ajax_targetURL+this.alt, ticket_removeItemDone);
}//}}}

/**
* Callback funkcia pre vymazavanie poloziek z tiketu.
*/
function ticket_removeItemDone(req)//{{{
{
	var res=eval(req.responseText);
	ticket_kurs = res[0];
	ticket_vyhra = res[1];

	// zmenime kombinacie ak sa zmenili priodobrani polozky
	var tmp = res[2];
	for (var key in combinations)
		combinations[key] = 0;

	for (var l=0; l<tmp.length; l++)
	{
		var detail = getDetailByBidId(tmp[l][1],tmp[l][0]);
		changeSelector(detail['id'], tmp[l][2]);
	}

	// ak sme odstranili posledny element so skupinou "B" zmena typu na AKO
	// zmena typu tiketu z FALC, KOMBI na AKO
	if (combinations['B']==0)
	{
		ticket_changeType(getobject("AKO"), true);
		disableOption("KOMBI");
		disableOption("FALC");
	}
	else
	{
		enableOption("KOMBI");
		
		if (combinations['T']>0)
		{
			disableOption("FALC");
			if (ticket_type=="FALC")
				ticket_changeType(getobject("KOMBI"), true);
		}
		else
		{
			enableOption("FALC");
		}
	}

	if (ticket_type == "KOMBI")
	{
		// ak je listok KOMBI a zmenil sa pocet kombinacii zmenime pocet inputov
		ticket_changeVklady(getCombinationsCount());
	}

	ticket_changeSummary();
}//}}}


/**
* Vytvorenie sablon pre polozky tiketu, potom sa pre jednotlive uz iba klonuju.
*/
function initializeRows()//{{{
{
	// prvy riadok
	var td_tmp11 = document.createElement('td');
	td_tmp11.style.borderLeft = "1px solid #FFF8DA";
	td_tmp11.style.paddingLeft = "10px";
	td_tmp11.style.color = ftColor_pending;
	td_tmp11.style.borderTop = "1px solid #FFF8DA";

	var td_tmp12 = document.createElement('td');
	td_tmp12.style.textAlign = "center";
	td_tmp12.style.color = ftColor_pending;
	td_tmp12.style.borderTop = "1px solid #FFF8DA";

	var closeImg  = document.createElement('img');
	closeImg.src = ajax_host+"/pub/img/icon_closeSmall.gif";

	var td_tmp13 = document.createElement('td');
	td_tmp13.style.borderRight = "1px solid #C2B16B";
	td_tmp13.style.borderTop = "1px solid #FFF8DA";
	td_tmp13.appendChild(closeImg);

	tr_firstRow = document.createElement('tr');
	tr_firstRow.appendChild(td_tmp11);
	tr_firstRow.appendChild(td_tmp12);
	tr_firstRow.appendChild(td_tmp13);

	// druhy riadok
	var td_tmp21 = document.createElement('td');
	td_tmp21.style.borderLeft = "1px solid #FFF8DA";
	td_tmp21.style.paddingLeft = "10px";
	td_tmp21.style.color = ftColor_pending;
	td_tmp21.style.borderBottom = "1px solid #C2B16B";
	td_tmp21.appendChild(selector);

	var td_tmp22 = document.createElement('td');
	td_tmp22.style.textAlign = "center";
	td_tmp22.style.color = ftColor_pending;
	td_tmp22.style.borderBottom = "1px solid #C2B16B";

	var td_tmp23 = document.createElement('td');
	td_tmp23.style.width = "9px";
	td_tmp23.style.borderRight = "1px solid #C2B16B";
	td_tmp23.style.borderBottom = "1px solid #C2B16B";

	tr_secondRow = document.createElement('tr');
	tr_secondRow.appendChild(td_tmp21);
	tr_secondRow.appendChild(td_tmp22);
	tr_secondRow.appendChild(td_tmp23);
}//}}}

/**
* AJAXove nacitanie tiketu na reload stranky.
*/
function ticket_onLoad()//{{{
{
	ajax_host = document.location.protocol+"//"+document.location.host;
	ajax_targetURL =  ajax_host+ajax_targetURL;

//	var td_spacer = document.createElement('td');
//	td_spacer.style.backgroundColor = "#FFD006" ;
//	td_spacer.style.height = "1px";
//	td_spacer.style.border = "0px";
//	td_spacer.style.padding = "0px";

//	tr_spacer = document.createElement('tr');
//	tr_spacer.appendChild(td_spacer);
	ajax_execCommand(ajax_targetURL+"?list_ticket=", ticket_onLoadDone);
}//}}}

/**
*/
function ticket_onLoadDone(req)//{{{
{
	var res=eval(req.responseText);
	if (!res)
		return;
	// nacitanie tipu tiketu
	var type = res[0];

	//nacitanie vkladov
	var vklady = res[1];
	ticket_vklad = new Array();
	for (var l=0; l<vklady.length; l++)
		ticket_vklad[l] = vklady[l];

	// naciteni kurzu
	ticket_kurs = res[2];

	ticket_vklad_tot = res[3];

	// nacitanie celkovej vyhry
	ticket_vyhra = res[4];
	
	// detaily poloziek tiketu
	selector= document.createElement('select');	
	selector.style.width="40px";
	for (var k=0; k<res[5].length; k++)
	{
		selector.options[k] = new Option(res[5][k],k);
		combinations[res[5][k]] = 0;

	}
	initializeRows();

	var ar = res[6];
	element_counter = 0;
	var tbl_ticketContent = getobject('ticket_content');
	for (var i=0;i<ar.length;i++)
	{
		element_details[element_counter] = new Array();
		element_details[element_counter]['valid'] = true;
		element_details[element_counter]['id'] = element_counter;
		element_details[element_counter]['info'] = ar[i]['info'];
		element_details[element_counter]['skup'] = ar[i]['skup'];
		element_details[element_counter]['kurs'] = ar[i]['kurs'];
		element_details[element_counter]['hodn'] = ar[i]['hodn'];
		element_details[element_counter]['match_name'] = ar[i]['meno'];
		element_details[element_counter]['match_time'] = ar[i]['time'];
		element_details[element_counter]['bid_typ'] = ar[i]['typ'];
		element_details[element_counter]['bid_id'] = ar[i]['id'];

		createTicketItemRow(tbl_ticketContent, element_details[element_counter], element_counter);
	
		ticket_itemValid(element_counter);
		element_counter++;	
	}
	if (type != "")
		ticket_changeType(getobject(type), false);

	ticket_changeSummary();
}//}}}


/**
*/
function ticket_recalculate()//{{{
{
	ticket_hideError();
	
	var vklady="";
	for (var i=0;i<10;i++)
	{
		var tmp = getobject('tiket_vklad_'+i);
		if (!tmp)
			break;
		if (tmp.value == "")
		{
			ticket_vklad[i] = 0;
			vklady += "0,";
		}
		else
		{
			ticket_vklad[i] = parseInt(tmp.value);
			vklady += tmp.value+",";
		}
	}
	ajax_execCommand(ajax_targetURL+"?chng_vklad="+vklady, ticket_recalculateDone);
}//}}}

/**
*/
function ticket_recalculateDone(req)//{{{
{
	var res=eval(req.responseText);
	ticket_kurs = res[0];
	ticket_vyhra = res[1];
	ticket_vklad_tot = res[2];
	ticket_changeSummary();
}//}}}


function ajax_execCommand(url, callbackFunc)//{{{
{
	ajax_requestCompleted = false;

	// create HTTP object
	if (window.XMLHttpRequest) //non IE
		req = new XMLHttpRequest();
	else if (window.ActiveXObject) // IE
		req = new ActiveXObject("Microsoft.XMLHTTP");

	// AJAX not supported
	if (req==null)
	{
		alert("Browser doesn't support AJAX.");
		ajax_requestCompleted = true;
	}
	else
	{
		// request callback function
		req.onreadystatechange = function() 
		{
			if(req.readyState==4)
			{
				ajax_requestCompleted = true;
				 if(req.status==200)
				{
					if (callbackFunc!= null)
						callbackFunc(req);
				}
				else
				{
				}
			}
		}	
		// execute query
		req.open("GET", url, true);
		req.send(null);
	}				
}//}}}

addLoadEvent(ticket_onLoad);

